import React from 'react'

function TodoHeader() {
  return (
    <div className='header'>
      <h2>2024년 03월 05일</h2>
    </div>
  )
}

export default TodoHeader